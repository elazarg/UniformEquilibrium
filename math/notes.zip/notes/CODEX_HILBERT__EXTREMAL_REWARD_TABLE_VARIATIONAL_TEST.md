# Extremal reward tables: active terminal laws and a one-player normal certificate

Owner: `CODEX_HILBERT`.

Status: **ordinary mathematical proof, internal and not independently reviewed**.
The extremal-table separation argument is valid without attainment of the
profile infimum or of any best-response cap. Its proposed 60-vector conclusion
improves to at most 15 limiting law differences belonging to one player.
This is a necessary condition for a positive local maximum of the unrestricted
exploitability value on the normalized reward cube. It neither produces a
positive-gap game nor proves that the value vanishes. No Lean work or export
is claimed.

## 1. Question, finite data, and source audit

There are four players I = {0,1,2,3}, fifteen nonempty quitting coalitions
C = 2ᴵ ∖ {∅}, and one additional terminal outcome ∞ for Never. A reward table
r belongs to R = [−1,1]^(I×C); Never pays zero to everyone. Until absorption,
players see the unique public all-Continue history and use independent
behavioral randomization. A deviation replaces one complete behavioral
strategy. All payoffs below are expected terminal payoffs, including zero on
Never. No public correlation device, bounded controller, or finite-clock
restriction is imposed.

Let Σ be the common space of actual behavioral profiles, independent of r.
For σ ∈ Σ, let μσ be its probability law on C ∪ {∞}. For a player i and a
complete deviation τᵢ, let νσ,i,τ be the terminal law after that deviation.
Define a vector vσ,i,τ ∈ ℝ^(I×C) by

    vσ,i,τ(j,S) = 0                         if j ≠ i,
    vσ,i,τ(i,S) = νσ,i,τ(S) − μσ(S)         if j = i.

Thus v·r is exactly the deviator's expected terminal gain. Write

    Vσ = {vσ,i,τ : i ∈ I, τᵢ any complete behavioral deviation},
    fσ(r) = sup {v·r : v ∈ Vσ},
    η(r) = inf {fσ(r) : σ ∈ Σ}.

The unchanged strategy is allowed, so 0 ∈ Vσ and fσ ≥ 0. The vectors have
ℓ¹ norm at most 2. Every fσ and η is 2-Lipschitz in the uniform norm, and
η(ar) = aη(r) for a ≥ 0. The functions fσ are convex support functions;
convexity of their infimum η is neither assumed nor inferred.

The question is conditional: suppose r* is a local maximum of η relative to
R, with γ = η(r*) > 0. What actual-law restrictions does this impose? A
global positive maximum exists if any positive-gap reward table exists:
positive scaling puts such a table in R, and Lipschitz continuity gives
attainment of the maximum on compact R. This is attainment in reward space,
not in profile space. Also γ ≤ 1 at a global maximum: the all-Never profile
has exploitability maxᵢ max(0,rᵢ({i})) ≤ 1.

Bounded source inspection used the semantic waist and reward-robustness route
in `docs/FRONTIER.md`. Declarations read under their imports were:

- `quittingUniformEquilibriumPayoffConjecture` in
  `UniformEquilibrium/Quitting/Conjecture/Basic.lean`: the open target.
- `quittingTerminalPayoff` in
  `UniformEquilibrium/ProofView/Concepts/Stochastic/Models/Quitting/Asymptotic.lean`:
  the finite reward-weighted absorption-mass formula, with zero Never payoff.
- `quittingTerminalExploitabilityInf`,
  `hasTerminalExploitabilityGap_of_lt_quittingTerminalExploitabilityInf`, and
  `quittingTerminalExploitabilityInf_pos_of_no_uniformEquilibriumPayoff` in
  `UniformEquilibrium/Quitting/Terminal/TerminalDebtPrefixDescent.lean`.
- `HasTerminalExploitabilityGap` and
  `not_exists_uniformEquilibriumPayoff_iff_exists_terminalExploitabilityGap`
  in `UniformEquilibrium/Quitting/Terminal/ExploitabilityGap.lean`.
- `quittingGame_exists_uniformEquilibriumPayoff_iff_terminalNash_all_errors`
  in `UniformEquilibrium/Quitting/Terminal/TargetTail/TerminalUniformPayoffSelection.lean`.
- `abs_quittingTerminalExploitabilityInf_sub_le_of_reward_close` and
  `quittingTerminalExploitabilityInf_scaleQuittingReward` in
  `Research/Quitting/TerminalExploitabilityRewardRobustness.lean`.

These are source inspections, not a Lean build or axiom audit performed here.
Narrow searches in the terminal and robustness files located the exact
supremum/infimum definitions and existing strict-gap caveat. A narrow search
of `Literature/` for extremal reward and normal-cone claims found no directly
used paper result. `Literature/README.md` was read; no literature theorem is
invoked. The earlier conference note
[`CODEX_ROOT__GENERIC_REWARD_REDUCTION_FOR_FIN4.md`](CODEX_ROOT__GENERIC_REWARD_REDUCTION_FOR_FIN4.md)
records the different dense-class consequence of reward robustness.

## 2. The correct limiting active family

For ε > 0 define Aε to contain exactly the vectors v ∈ Vσ for which some
actual profile σ satisfies

    fσ(r*) ≤ γ + ε,
    v·r* ≥ fσ(r*) − ε.                                      (1)

Both inequalities use the same actual σ. The response in (1) is approximate
and need not attain a cap. Set

    K = ⋂[ε > 0] closure(Aε).                                (2)

All closures are in finite-dimensional reward-coordinate space. The sets
closure(Aε) are nested, nonempty compact subsets of the ℓ¹ ball of radius 2.
Nonemptiness follows by first choosing an ε-near-minimizing actual profile
and then an ε-near-maximizing actual response. Therefore K is nonempty and
compact. Equivalently, v ∈ K precisely when v is the limit of vₙ ∈ Vσₙ with

    fσₙ(r*) → γ,
    fσₙ(r*) − vₙ·r* → 0.                                   (3)

Every v ∈ K has

    v·r* = γ,       ‖v‖₁ ≤ 2,                              (4)

and is supported on one player's fifteen coordinates. The latter property
is closed because it is a finite union of coordinate subspaces. Since γ > 0,
no member of K is zero, so its player is unique. Write Kᵢ for its part
supported on player i.

K does not assert that different vectors use a common profile. A sequence
of profiles need not converge to an actual minimizer. Each vector separately
retains the approximation provenance (3); nothing stronger is built into (2).

## 3. Separation theorem, including all approximation quantifiers

Let N be the outward normal cone of R at r*:

    N = {g : g·(r − r*) ≤ 0 for every r ∈ R}.

Coordinatewise this says gₖ = 0 when |r*ₖ| < 1, gₖ ≥ 0 when r*ₖ = 1, and
gₖ ≤ 0 when r*ₖ = −1. Let T be its polar cone, the feasible infinitesimal
directions into the cube. Every d ∈ T has r* + td ∈ R for all sufficiently
small t ≥ 0, since the cube has finitely many coordinates.

**Theorem 1.** If r* is a positive local maximum as above, then

    conv(K) ∩ N ≠ ∅.                                       (5)

**Proof.** Suppose H = conv(K) is disjoint from N. H is compact and N is a
closed convex cone. Choose a closest pair p ∈ H, n ∈ N and set d = p − n.
The positive distance implies d ≠ 0. The minimizing-pair inequalities give

    d·h ≥ d·p    for h ∈ H,
    d·z ≤ d·n    for z ∈ N.

The cone property, by taking z = 0 and z = 2n, gives d·n = 0; scaling any
z ∈ N then gives d·z ≤ 0. Consequently d ∈ T and

    min[v ∈ K] d·v ≥ ‖d‖₂² > 0.                            (6)

Fix c > 0 smaller than the minimum in (6). There is ε₀ > 0 such that

    d·v ≥ c for every v ∈ Aε₀.                             (7)

Otherwise choose εₙ ↓ 0 and vₙ ∈ Aεₙ violating (7). A convergent subsequence
of the bounded vₙ has limit in K, contradicting (6). This is the uniform
step that prevents the profile family from escaping the separator.

Put L = 2‖d‖∞ > 0. Choose t > 0 so small that r* + td lies in the local
maximum neighborhood inside R, Lt ≤ ε₀/2, and tc/2 ≤ ε₀. Consider an
arbitrary actual profile σ.

If fσ(r*) > γ + ε₀, the Lipschitz bound gives

    fσ(r* + td) > γ + ε₀ − Lt ≥ γ + ε₀/2.                  (8)

If fσ(r*) ≤ γ + ε₀, choose an actual response v ∈ Vσ with

    v·r* ≥ fσ(r*) − tc/2.

Such a response exists from the definition of the supremum. Its error is
at most ε₀, so v ∈ Aε₀ and (7) applies. Hence

    fσ(r* + td) ≥ v·(r* + td)
                 ≥ fσ(r*) − tc/2 + tc
                 ≥ γ + tc/2.                              (9)

Taking the infimum of (8)–(9) over every actual σ gives

    η(r* + td) ≥ γ + min(ε₀/2,tc/2) > γ,

contradicting local maximality. This proves (5). ∎

Notice what the argument does not do: it never picks one response attaining
every cap, never interchanges infimum and supremum, and never takes a convex
combination of profiles as an executable strategy.

**Corollary 2.** There are m ≤ 60, v¹,…,vᵐ ∈ K, and nonnegative weights
αₐ summing to one such that g = Σₐ αₐvᵃ ∈ N. Moreover

    r*·g = ‖g‖₁ = γ > 0.                                  (10)

Indeed, K lies in the affine hyperplane r*·v = γ, of dimension at most 59;
the finite-dimensional convex-hull reduction therefore needs at most 60
points. Equation (10) uses (4) and the explicit cube normal signs. The
hyperplane is proper since γ > 0 forces r* ≠ 0.

## 4. The player blocks sharpen 60 to 15

**Theorem 3.** There is one player i, m ≤ 15, points w¹,…,wᵐ ∈ Kᵢ, and
weights αₐ ≥ 0 summing to one such that h = Σₐ αₐwᵃ lies in N. In particular

    h is supported on player i,
    r*ᵢ·hᵢ = ‖hᵢ‖₁ = γ.                                  (11)

**Proof.** Start with Corollary 2 and group its terms by player. Let λᵢ be
the total weight for player i, and gᵢ the corresponding coordinate block.
At least one λᵢ is positive. Since the cube normal cone is the product of
its coordinate cones, retaining only gᵢ and dividing it by λᵢ stays in N.
That vector is a convex combination of elements of Kᵢ. Each such element
has r*ᵢ·wᵢ = γ, so the combination is nonzero and satisfies (11).

The relevant Kᵢ lies in a proper affine hyperplane in ℝ¹⁵ of dimension at
most 14. Convex-hull reduction inside that block gives at most 15 elements.
For completeness, this reduction repeatedly removes a coefficient: if more
than 15 positively weighted points remain, they have an affine dependence
Σ βₐwᵃ = 0, Σ βₐ = 0; subtract the largest permitted multiple of β from
the coefficients so one becomes zero and none becomes negative. ∎

This is a real improvement over generic sixty-dimensional stationarity.
It localizes the necessary law balance to a single player's reward vector.
It does not say that this player is the unique debtor, nor that one of the
individual wᵃ already belongs to N.

## 5. Full-law interpretation and its precise limitation

For each wᵃ in Theorem 3, pass to a subsequence in its realizing family (3)
so the two full terminal laws also converge in the sixteen-outcome simplex.
Denote the limits by μᵃ and νᵃ. Their nonempty-coalition difference is wᵃᵢ.
They are limits of actual same-source unilateral law pairs for the same i.
They need not be a unilateral pair at one limiting actual profile.

Define averaged probability laws

    μ̄ = Σₐ αₐ μᵃ,       ν̄ = Σₐ αₐ νᵃ.

Then hᵢ(S) = ν̄(S) − μ̄(S). The cube normal identities imply exactly:

- at every coalition with |r*ᵢ(S)| < 1, ν̄(S) = μ̄(S);
- at reward +1 coalitions, ν̄(S) ≥ μ̄(S);
- at reward −1 coalitions, ν̄(S) ≤ μ̄(S).

Put a = Σ[r*ᵢ(S)=1](ν̄(S)−μ̄(S)) and
b = Σ[r*ᵢ(S)=−1](μ̄(S)−ν̄(S)). Then

    a ≥ 0,   b ≥ 0,   a + b = γ,
    ν̄(∞) − μ̄(∞) = b − a,
    TV(ν̄,μ̄) = max(a,b) ∈ [γ/2,γ].                         (12)

The total-variation convention is half the ℓ¹ distance on all sixteen
outcomes. Thus at least one saturated reward coordinate in this one player
block has averaged law change of magnitude at least γ/15. Formula (12)
also exposes why subtracting a constant from all nonempty rewards is not a
valid strategic invariance: the average Never masses can differ.

These are probability-law consequences beyond the bare normal equation.
Their current consumer is a necessary-condition search test: an alleged
positive extremal reward table must admit this one-player, at-most-15-term
balance among its globally near-minimizing actual law pairs. A verified
separation of the *complete* Kᵢ from the corresponding normal cone for every
i would rule out positive local maximality and produce the improving
direction used above. A finite sampled subset cannot certify that separation
for the complete family. Conversely, finding a balanced sample is not a
positive lower bound on η.

## 6. Exact tests and unresolved conclusion

The following toy portfolio refutes only a generic corner inference. On
[−1,1]² put

    F(x,y) = min(|x|, |x+y|/2, |x−y|/2).

Each constituent is a support function of finitely many vectors of ℓ¹ norm
at most 2, and F is nonnegative, Lipschitz, and positively homogeneous.
Since min(|x+y|,|x−y|) = ||x|−|y||, one obtains max F = 1/2, attained at
(±1,0), while F vanishes at all four corners. At (1,0) the active gradients
(1/2,1/2) and (1/2,−1/2) average to the outward normal (1/2,0). Neither
individual active gradient is normal. This tests both the need for convex
combination and the failure of generic corner reduction. It is not an
actual quitting-game η and does not refute a special corner theorem for η.

Actual unilateral law provenance by itself is compatible with a nonzero
normal, even at every gain in the admissible range (0,1]. Fix 0 < c ≤ 1,
let player 1 quit surely at date 1, and let player 0 quit at date 0 with
probability q = 1 − c/2 and otherwise Never; players 2 and 3 Never. Set
r₀({0}) = 1 and r₀({1}) = −1; let every other coordinate be zero.
The baseline law is q e_{0} + (1−q)e_{1}. Player 0's deviation to Quit
surely at date 0 has law e_{0}, giving the literal difference

    (c/2)(e_(0,{0}) − e_(0,{1})).

This is a cube normal of ℓ¹ norm c and an exact cap response with gain c.
All other players' debts are zero, so the actual profile has fσ = c. But
the game has η = 0: player 0 quitting at date 0 with all others Never is
terminal Nash. Thus full probability-law provenance, player locality, exact
cap attainment, the normal signs, and the bound c ≤ 1 do not themselves
forbid the pattern. What fails is specifically global near-minimality: this
profile remains c above the true infimum. The example does not satisfy
(1)–(3) with γ = c and does not falsify any theorem above.

Proved: the approximation-safe separation theorem, the one-player 15-term
certificate, and the averaged-law restrictions (12).

Open: whether actual global near-minimality imposes an additional constraint
on those law pairs that makes the certificate impossible at positive γ.
The current proof supplies no such constraint and no contradiction. In
particular, its averaged laws are not silently treated as one actual profile
or one simultaneously optimal family of responses.

Concrete requested check: independently verify the uniform step (7), the
two profile regimes (8)–(9), and the block reduction in Theorem 3; then try
to use the exact same-source provenance of each law pair, together with
global near-minimality, to restrict the possible interior-coordinate
cancellations in their convex mixture. No export is warranted before that
review, and no closure of the finite-quitting conjecture is claimed.
