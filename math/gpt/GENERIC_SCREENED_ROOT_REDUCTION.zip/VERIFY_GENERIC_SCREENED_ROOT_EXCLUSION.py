"""Exact finite regressions for the screened-root resultant reduction.

All calculations use fractions.Fraction, Python integers, and exact SymPy interpolation.  This is not a
counterexample search, a proof of genericity, or a Lean validation.  The universal
proof is in GENERIC_SCREENED_ROOT_EXCLUSION_AND_SINGLETON_MASS_COLLAR.md.

Run: python VERIFY_GENERIC_SCREENED_ROOT_EXCLUSION.py
"""
from __future__ import annotations

from fractions import Fraction as F
from itertools import combinations, product
import json
from pathlib import Path
from random import Random

PLAYERS = tuple(range(4))
PAIRS = tuple(combinations(PLAYERS, 2))
MODES = tuple(product((False, True), repeat=2))  # True = Quit preferred
Table = dict[int, tuple[F, F, F, F]]


def mask(players) -> int:
    return sum(1 << i for i in players)


def det3(a) -> F:
    return (a[0][0] * (a[1][1]*a[2][2] - a[1][2]*a[2][1])
            - a[0][1] * (a[1][0]*a[2][2] - a[1][2]*a[2][0])
            + a[0][2] * (a[1][0]*a[2][1] - a[1][1]*a[2][0]))


def coeff(corners) -> tuple[F, F, F, F]:
    f00, f10, f01, f11 = corners
    return f00, f10-f00, f01-f00, f11-f10-f01+f00


def raw_rows(r: Table, pair, modes):
    i, j = pair
    k, ell = [p for p in PLAYERS if p not in pair]
    K = mask(pair)
    corners = [(0, 0), (1, 0), (0, 1), (1, 1)]
    rows = []
    for owner in (i, j):
        values = []
        for x, y in corners:
            A = K | ((1 << k) if x else 0) | ((1 << ell) if y else 0)
            values.append(r[A ^ (1 << owner)][owner] - r[A][owner])
        rows.append(coeff(values))
    for owner, other, mode in ((k, ell, modes[0]), (ell, k, modes[1])):
        values = []
        for x, y in corners:
            own, opp = (x, y) if owner == k else (y, x)
            A = K | ((1 << other) if opp else 0)
            gap = r[A | (1 << owner)][owner] - r[A][owner]
            values.append((1-own)*gap if mode else -own*gap)
        rows.append(coeff(values))
    return tuple(rows)


def certificate(r: Table, pair, modes):
    rows = raw_rows(r, pair, modes)
    A = tuple(tuple(row[t]-rows[0][t] for t in range(4)) for row in rows[1:])
    w = tuple((-1)**t * det3(tuple(tuple(row[j] for j in range(4) if j != t)
                                  for row in A)) for t in range(4))
    # Signed cofactor vector is always in the nullspace.
    assert all(sum(row[t]*w[t] for t in range(4)) == 0 for row in A)
    P = w[0]*w[3]-w[1]*w[2]
    return A, w, P


def at(row, x: F, y: F) -> F:
    return row[0]+row[1]*x+row[2]*y+row[3]*x*y


def one_date_payoff(r: Table, q) -> tuple[F, F, F, F]:
    u = [F(0)]*4
    for bits in product((0, 1), repeat=4):
        mass = F(1)
        for i, bit in enumerate(bits):
            mass *= q[i] if bit else 1-q[i]
        S = sum((1 << i) for i, bit in enumerate(bits) if bit)
        if S:
            for i in PLAYERS:
                u[i] += mass*r[S][i]
    return tuple(u)


def complete_root_debts(r: Table, q) -> tuple[F, F, F, F]:
    """For >=2 sure Quit0 laws, later finite dates and Never equal Continue0."""
    assert sum(value == 1 for value in q) >= 2
    u = one_date_payoff(r, q)
    debts = []
    for i in PLAYERS:
        endpoints = []
        for own in (F(0), F(1)):
            replacement = list(q)
            replacement[i] = own
            endpoints.append(one_date_payoff(r, replacement)[i])
        debts.append(max(endpoints)-u[i])
    return tuple(debts)


def prescribed_gap_fixture(pair, modes, first, second, gk, gl) -> Table:
    """Install four recipient-disjoint membership-gap rows, own singletons zero."""
    r = {S: [F(0)]*4 for S in range(1, 16)}
    i, j = pair
    k, ell = [p for p in PLAYERS if p not in pair]
    K = mask(pair)
    for owner, fn in ((i, first), (j, second)):
        for x, y in product((0, 1), repeat=2):
            A = K | ((1 << k) if x else 0) | ((1 << ell) if y else 0)
            gap = fn(F(x), F(y))
            r[A ^ (1 << owner)][owner] = gap/2
            r[A][owner] = -gap/2
    for owner, other, gap in ((k, ell, gk), (ell, k, gl)):
        for bit in (0, 1):
            A = K | ((1 << other) if bit else 0)
            r[A][owner] = -gap/2
            r[A | (1 << owner)][owner] = gap/2
    return {S: tuple(v) for S, v in r.items()}


def run_checks():
    counts = {"nonzero_polynomial_witnesses": 0, "full_debt_branch_checks": 0,
              "cofactor_nullspace_checks": 0, "singleton_invariance_checks": 0,
              "exceptional_tied_boundary_checks": 0}
    # For each individual polynomial, a bounded rational nonvanishing witness.
    for pair in PAIRS:
        for modes in MODES:
            gaps = [F(1, 4) if mode else F(-1, 4) for mode in modes]
            r = prescribed_gap_fixture(pair, modes, lambda x,y: F(1,4),
                    lambda x,y: F(1,2)+x*y/4, *gaps)
            assert all(abs(v) <= 1 for row in r.values() for v in row)
            A, w, P = certificate(r, pair, modes)
            assert P != 0
            counts["nonzero_polynomial_witnesses"] += 1
            counts["cofactor_nullspace_checks"] += 1

    rng = Random(20260909)
    for _ in range(24):
        r = {S: tuple(F(rng.randrange(-9,10), 10) for _ in PLAYERS)
             for S in range(1,16)}
        changed = {S: list(v) for S,v in r.items()}
        for i in PLAYERS:
            changed[1 << i][i] = F(rng.randrange(-50,51), 7)
        changed = {S: tuple(v) for S,v in changed.items()}
        for pair in PAIRS:
            k, ell = [p for p in PLAYERS if p not in pair]
            # Includes boundary optional probabilities 0 and 1.
            x, y = F(rng.randrange(6), 5), F(rng.randrange(6), 5)
            q = [F(1)]*4
            q[k], q[ell] = x, y
            debts = complete_root_debts(r, q)
            branches = []
            for modes in MODES:
                rows = raw_rows(r, pair, modes)
                branches.append(tuple(at(row, x, y) for row in rows))
                A, w, P = certificate(r, pair, modes)
                assert certificate(changed, pair, modes) == (A,w,P)
                counts["singleton_invariance_checks"] += 1
                counts["cofactor_nullspace_checks"] += 1
            i,j = pair
            assert debts[i] == max(F(0), branches[0][0])
            assert debts[j] == max(F(0), branches[0][1])
            assert debts[k] == max(branch[2] for branch in branches)
            assert debts[ell] == max(branch[3] for branch in branches)
            counts["full_debt_branch_checks"] += 1

    # Actual equal-positive-debt roots, deliberately NOT global minima:
    # all own singletons are zero, so all Never is an exact equilibrium.
    for pair in PAIRS:
        for x,y,modes in [(F(1,2), F(2,3), (True,True)),
                           (F(1), F(1,2), (False,True)),
                           (F(1), F(1), (False,False))]:
            m = F(1,8)
            gk = m/(1-x) if modes[0] else -m/x
            gl = m/(1-y) if modes[1] else -m/y
            r = prescribed_gap_fixture(pair,modes,lambda a,b:m,lambda a,b:m,gk,gl)
            k,ell = [p for p in PLAYERS if p not in pair]
            q = [F(1)]*4
            q[k],q[ell] = x,y
            assert complete_root_debts(r,q) == (m,m,m,m)
            assert certificate(r,pair,modes)[2] == 0
            counts["exceptional_tied_boundary_checks"] += 1

    # One concrete rational table on which ALL 24 polynomials are nonzero.
    attempts = 0
    while True:
        attempts += 1
        integer_table = {S: tuple(rng.randrange(-3,4) for _ in PLAYERS)
                         for S in range(1,16)}
        for i in PLAYERS:
            values = list(integer_table[1 << i]); values[i] = 1
            integer_table[1 << i] = tuple(values)
        integer_values = {(pair,modes): certificate(integer_table,pair,modes)[2]
                          for pair in PAIRS for modes in MODES}
        if all(value != 0 for value in integer_values.values()):
            break
        assert attempts < 1000
    normalized = {S: tuple(F(v,4) for v in row) for S,row in integer_table.items()}
    for pair in PAIRS:
        for modes in MODES:
            assert certificate(normalized,pair,modes)[2] == integer_values[pair,modes]/4**6
    # A nonvanishing fixture close to the supplied sure-anchor example.
    # Its parent has an equilibrium, but its >=2-sure root floor is positive.
    def anchor_reward(S, i):
        present = lambda j: int(bool(S & (1 << j)))
        if i == 0:
            return 1 if present(0) else 2*present(2)
        if i == 1:
            return (2*present(0)-1)*present(1)
        if i == 2:
            return (2*present(1)-1)*present(2)
        return present(3)
    anchor_attempts = 0
    while True:
        anchor_attempts += 1
        near = {S: tuple(1000*anchor_reward(S,i) +
                    (0 if S == (1 << i) else rng.randrange(-3,4))
                    for i in PLAYERS) for S in range(1,16)}
        near_values = {(pair,modes): certificate(near,pair,modes)[2]
                       for pair in PAIRS for modes in MODES}
        if all(value != 0 for value in near_values.values()):
            break
        assert anchor_attempts < 1000
    # sqrt(17) < 33/8 gives the center's scaled floor >7/128.
    assert F(17) < F(33,8)**2
    assert F(7,128)-F(3,2000) > F(1,20)

    # First-order complete cap-Continue prefix ledger, by exact polynomial
    # interpolation (the polynomial has degree at most four).
    import sympy as sp
    t = sp.Symbol("t")
    first_order_checks = 0
    for _ in range(8):
        r = {S: tuple(F(rng.randrange(-5,6), 7) for i in PLAYERS)
             for S in range(1,16)}
        m = F(1,10)
        L = [F(rng.randrange(2,8), 9) for i in PLAYERS]
        lam = [1/a for a in L]
        B = [r[1 << i][i]+L[i] for i in PLAYERS]
        U = [a-m for a in B]
        samples = [[] for i in PLAYERS]
        for time in [F(j,100) for j in range(5)]:
            q = [time*a for a in lam]
            up = list(one_date_payoff(r,q))
            survival = F(1)
            for a in q:
                survival *= 1-a
            for i in PLAYERS:
                up[i] += survival*U[i]
                opponents = [j for j in PLAYERS if j != i]
                cp = F(0)
                for bits in product((0,1),repeat=3):
                    mass = F(1); S = 0
                    for j,bit in zip(opponents,bits):
                        mass *= q[j] if bit else 1-q[j]
                        if bit: S |= 1 << j
                    cp += mass*(r[S][i] if S else B[i])
                samples[i].append((sp.Rational(time.numerator,time.denominator),
                                   sp.Rational((cp-up[i]).numerator,(cp-up[i]).denominator)))
        for i in PLAYERS:
            poly = sp.interpolate(samples[i],t).expand()
            expected = lam[i]*L[i]-m*sum(lam)
            assert poly.coeff(t,1) == sp.Rational(expected.numerator,expected.denominator)
            assert poly.coeff(t,0) == sp.Rational(m.numerator,m.denominator)
            first_order_checks += 1
    counts["harmonic_ledger_coordinate_checks"] = first_order_checks
    return {"status":"passed", "counts":counts,
            "fixture_search_attempts":attempts,
            "fixture_integer_table_divisor":4,
            "fixture_integer_table":{str(S):v for S,v in integer_table.items()},
            "fixture_certificate_numerators":{
                f"{pair[0]}{pair[1]}:{''.join('Q' if b else 'C' for b in modes)}": int(value)
                for (pair,modes),value in integer_values.items()},
            "fixture_certificate_common_denominator":4**6,
            "fixture_min_abs_certificate":str(min(abs(v) for v in integer_values.values())/F(4**6)),
            "near_anchor_fixture":{
                "search_attempts":anchor_attempts,
                "divisor":4000,
                "integer_table":{str(S):v for S,v in near.items()},
                "all_24_polynomials_nonzero":True,
                "screened_root_floor_strict_lower_bound":"1/20",
                "certificate_numerators":{
                    f"{pair[0]}{pair[1]}:{''.join('Q' if b else 'C' for b in modes)}":int(value)
                    for (pair,modes),value in near_values.items()},
                "certificate_common_denominator":4000**6,
                "scope":"Solved parent near the supplied anchor example, NOT a positive-gap table."},
            "scope":"Algebraic regression only; fixture is not asserted to have positive global gap."}


if __name__ == "__main__":
    result = run_checks()
    output = Path(__file__).with_name("GENERIC_SCREENED_ROOT_CHECKS.json")
    output.write_text(json.dumps(result, indent=2)+"\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
