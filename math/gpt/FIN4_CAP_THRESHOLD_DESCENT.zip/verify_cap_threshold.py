#!/usr/bin/env python3
"""Exact-rational regression checks for CAP_THRESHOLD_DEBT_DESCENT.md.

This does not verify the universal theorem in Lean. It independently computes
finite pure-time response caps and checks the explicit cap-threshold example,
plus finite randomized regressions for the auxiliary-prefix inequality.
"""
from __future__ import annotations
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json
import random

N = 4
SINGLE = (F(1), F(0), F(0), F(0))
Row = tuple[F, ...]
Table = dict[int, Row]


def endpoints(r: Table, q: Row, i: int) -> tuple[F, F, F]:
    """Quit value, Continue absorbing numerator, opponents' survival."""
    opponents = [j for j in range(N) if j != i]
    Q = H = F(0)
    beta = F(1)
    for j in opponents:
        beta *= 1-q[j]
    for bits in product((0, 1), repeat=len(opponents)):
        prob, mask = F(1), 0
        for j, bit in zip(opponents, bits):
            prob *= q[j] if bit else 1-q[j]
            if bit:
                mask |= 1 << j
        Q += prob * r[mask | (1 << i)][i]
        if mask:
            H += prob * r[mask][i]
    return Q, H, beta


def prefix(r: Table, q: Row, U: Row, B: Row) -> tuple[Row, Row]:
    us, bs = [], []
    for i in range(N):
        Q, H, beta = endpoints(r, q, i)
        us.append(q[i]*Q + (1-q[i])*(H + beta*U[i]))
        bs.append(max(Q, H + beta*B[i]))
    return tuple(us), tuple(bs)


def semantics_recursive(r: Table, rows: list[Row]) -> tuple[Row, Row]:
    U = (F(0),)*N
    B = tuple(max(F(0), r[1 << i][i]) for i in range(N))
    for q in reversed(rows):
        U, B = prefix(r, q, U, B)
    return U, B


def semantics_direct(r: Table, rows: list[Row]) -> tuple[Row, Row]:
    """Forward outcome sums and every pure response class, including late/Never."""
    U = [F(0)]*N
    reach = F(1)
    for q in rows:
        for bits in product((0, 1), repeat=N):
            prob, mask = reach, 0
            for j, bit in enumerate(bits):
                prob *= q[j] if bit else 1-q[j]
                if bit:
                    mask |= 1 << j
            if mask:
                for i in range(N):
                    U[i] += prob*r[mask][i]
        for x in q:
            reach *= 1-x
    caps = []
    for i in range(N):
        past, survive = F(0), F(1)
        replies = []
        for q in rows:
            Q, H, beta = endpoints(r, q, i)
            replies.append(past + survive*Q)
            past += survive*H
            survive *= beta
        replies.extend((past + survive*r[1 << i][i], past))
        caps.append(max(replies))
    return tuple(U), tuple(caps)


def debt(U: Row, B: Row) -> F:
    return sum((b-u for u, b in zip(U, B)), F(0))


def regret(r: Table, q: Row, v: Row) -> Row:
    ans = []
    for i in range(N):
        Q, H, beta = endpoints(r, q, i)
        C = H + beta*v[i]
        ans.append(max(Q, C) - q[i]*Q - (1-q[i])*C)
    return tuple(ans)


def explicit_example() -> dict:
    # Complete canonical table. The game is a regression example, not a new
    # equilibrium class: the all-Quit root is already an exact equilibrium.
    r = {mask: tuple(SINGLE[i] if mask & (1 << i) else F(-1)
                     for i in range(N)) for mask in range(1, 1 << N)}
    r[6] = (F(1), F(1), F(1), F(1))       # {1,2}
    r[7] = (F(2), F(-1), F(-1), F(-1))    # {0,1,2}
    M = F(2)
    old_rows = [(F(0), F(1), F(1), F(0))]
    U0, B0 = semantics_recursive(r, old_rows)
    assert U0 == (F(1),)*4
    assert B0 == (F(2), F(1), F(1), F(1))
    D = debt(U0, B0)
    assert D == 1
    L = B0[0]-SINGLE[0]
    theta = D/(32*(M+D))
    rho = 1-theta
    threshold = 4*M*theta
    q = (theta, F(0), F(0), F(0))
    U, B = U0, B0
    m = 0
    while all(B[j]-SINGLE[j] > threshold for j in (1,2,3)):
        for j in (1,2,3):
            Q, H, beta = endpoints(r, q, j)
            assert Q <= H + beta*B[j]  # No cap reset on this step.
        U, B = prefix(r, q, U, B)
        m += 1
        assert B[0] == B0[0]
        for j in (1,2,3):
            assert B[j] == -1 + rho**m*(B0[j]+1)
        assert debt(U,B) == rho**m*D + (1-rho**m)*L
        assert m < 10000
    assert m == 59
    rows = [q]*m + old_rows
    assert semantics_direct(r, rows) == (U, B)
    assert semantics_recursive(r, rows) == (U, B)
    assert all(B[j]-SINGLE[j] <= threshold for j in (1,2,3))
    assert debt(U,B) == 1
    h = D/2
    v = tuple(x-h for x in B)
    assert v[1] <= SINGLE[1]-3*D/8
    auxiliary = (F(1),)*4
    assert regret(r, auxiliary, v) == (F(0),)*4
    Uend, Bend = prefix(r, auxiliary, U, B)
    charge = 3*D*D/(32*M+6*D)
    assert debt(Uend, Bend) <= D-charge
    assert debt(Uend, Bend) == 0
    assert semantics_direct(r, [auxiliary]+rows) == (Uend,Bend)
    return {
        "initial_U": list(map(str,U0)), "initial_B": list(map(str,B0)),
        "initial_D": str(D), "theta": str(theta),
        "cap_threshold": str(threshold), "solo_prefixes": m,
        "crossing_outsider_cap": str(B[1]),
        "crossing_outsider_cap_decimal": float(B[1]),
        "crossing_D": str(debt(U,B)),
        "certified_minimum_drop": str(charge),
        "actual_final_D": str(debt(Uend,Bend)),
        "direct_unrestricted_caps_checked": True,
        "no_outsider_cap_reset_before_crossing": True,
        "scope": "The fixture already has the all-Quit equilibrium; it checks the ledger, not novelty or general existence."
    }


def finite_regressions(count: int = 300) -> dict:
    rng = random.Random(260907)
    hazard_menu = [F(k,4) for k in range(5)]
    for _ in range(count):
        r = {mask: tuple(F(rng.randint(-3,3)) for i in range(N))
             for mask in range(1,1 << N)}
        for i in range(N):
            vals = list(r[1 << i]); vals[i] = SINGLE[i]
            r[1 << i] = tuple(vals)
        rows = [tuple(rng.choice(hazard_menu) for _ in range(N))
                for _ in range(rng.randrange(0,7))]
        U, B = semantics_recursive(r, rows)
        assert semantics_direct(r, rows) == (U, B)
        assert all(b >= u for b,u in zip(B,U))
        D = debt(U,B)
        q = tuple(rng.choice(hazard_menu) for _ in range(N))
        h = F(rng.randrange(0,17),4)
        v = tuple(x-h for x in B)
        gs = regret(r,q,v)
        un,bn = prefix(r,q,U,B)
        c = F(1)
        for x in q:
            c *= 1-x
        single_mass = F(0)
        for i in range(N):
            _, _, beta = endpoints(r,q,i)
            pi = q[i]*beta
            single_mass += pi
            assert bn[i]-un[i] <= c*(B[i]-U[i])+pi*h+gs[i]
        assert debt(un,bn) <= c*D+h*single_mass+sum(gs,F(0))
        assert semantics_direct(r,[q]+rows) == (un,bn)
    return {"finite_actual_profile_tests":count,
            "auxiliary_ledger_tests":count,
            "arithmetic":"fractions.Fraction", "seed":260907,
            "universal_theorem_Lean_checked":False}



def pumping_regressions(target: int = 30) -> dict:
    """Check the literal first-hit ledger on additional actual signed sources."""
    rng = random.Random(260908)
    tested = attempts = largest_m = 0
    M = F(3)
    while tested < target and attempts < 5000:
        attempts += 1
        r = {mask: tuple(F(rng.randint(-3,3)) for _ in range(N))
             for mask in range(1,1 << N)}
        solos = tuple(r[1 << j][j] for j in range(N))
        rows = [tuple(F(rng.randint(0,4),4) for _ in range(N))
                for _ in range(rng.randint(1,4))]
        U0, B0 = semantics_recursive(r, rows)
        D = debt(U0,B0)
        if D <= 0:
            continue
        eligible = [i for i in range(N)
                    if any(r[1 << i][j] < solos[j] for j in range(N) if j != i)]
        if not eligible:
            continue
        i = min(eligible, key=lambda j: B0[j]-solos[j])
        L = B0[i]-solos[i]
        C = max(D,L)
        theta = C/(32*(M+C))
        rho, z = 1-theta, 4*M*theta
        if D <= C/2 or any(B0[j]-solos[j] <= z for j in range(N)):
            continue
        q = tuple(theta if j == i else F(0) for j in range(N))
        U, B = U0, B0
        m = 0
        while all(B[j]-solos[j] > z for j in range(N) if j != i):
            for j in range(N):
                if j != i:
                    Q, H, beta = endpoints(r,q,j)
                    assert H + beta*B[j] > Q
            U, B = prefix(r,q,U,B)
            m += 1
            assert m < 10000
            assert B[i] == B0[i]
            assert debt(U,B) == rho**m*D+(1-rho**m)*L
        for j in range(N):
            if j != i and B[j]-solos[j] <= z:
                assert B[j]-solos[j] > 2*M*theta
        assert semantics_direct(r,[q]*m+rows) == (U,B)
        largest_m = max(largest_m,m)
        tested += 1
    assert tested == target
    # Exact algebra at the claimed quadratic minimum collar.
    for m0 in (F(1), F(3,2), F(3), F(10)):
        for d0 in (F(1,7), F(1,2), F(1), F(2)):
            a0 = d0/(4*m0+d0)
            collar_debt = d0+d0*d0/(8*m0)
            assert (1-a0)*collar_debt+a0*d0/2 == d0
    return {"signed_actual_first_hit_tests":tested,
            "candidate_sources_examined":attempts,
            "largest_solo_block_tested":largest_m,
            "quadratic_collar_algebra_tests":16,
            "seed":260908}


def main() -> None:
    report = {"explicit_example": explicit_example(),
              "finite_regressions": finite_regressions(),
              "first_hit_regressions": pumping_regressions()}
    out = Path(__file__).with_name('verification.json')
    out.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__ == '__main__':
    main()
