#!/usr/bin/env python3
"""Exact finite checks for the two-pair payoff-exclusion selector example.

Python 3.10+, standard library only. Run:
    python CHECK_TWO_PAIR_SELECTOR.py

This verifies the rational table hypotheses, displayed constants, separation
witnesses, and absence of a root with two sure quitters. It does NOT certify
the general mathematical theorem, search all behavioral equilibria, or claim
the absence of the punishment-vector sure-quitter alternative.
"""
from fractions import Fraction as F
from itertools import combinations, product
import json
from pathlib import Path

# Coalition bitmask uses player i's bit 1<<i; mask zero is Never.
R = {
    0: (0, 0, 0, 0),
    1: (1, -2, F(-15,4), 0),
    2: (F(-5,2), 0, 1, -3),
    3: (2, 1, F(-3,4), F(-3,4)),
    4: (F(-7,4), F(-5,4), 0, F(-5,2)),
    5: (-3, F(1,2), F(1,2), F(-13,4)),
    6: (F(-3,2), F(-3,2), -2, F(-3,2)),
    7: (0, -3, F(7,4), F(-17,4)),
    8: (-2, F(-3,4), -4, 0),
    9: (F(-7,4), F(1,2), F(-9,4), F(1,4)),
    10: (F(1,2), -2, F(1,2), F(-15,4)),
    11: (F(5,4), F(-9,4), 0, -4),
    12: (F(1,4), F(-3,4), 1, 1),
    13: (F(-1,2), F(-5,2), F(3,2), F(-15,4)),
    14: (F(-3,4), F(-1,4), F(-1,2), F(-9,4)),
    15: (-1, F(-7,4), F(-7,2), F(3,2)),
}
R = {S: tuple(map(F, row)) for S, row in R.items()}
SOLO = (F(1), F(0), F(0), F(0))

def surplus_means(S):
    w = [R[S][i] - SOLO[i] for i in range(4)]
    return (w[0]+w[1])/2, (w[2]+w[3])/2

def quit_minus_continue(i, q):
    """Stage endpoint gap; valid when a distinct sure quitter screens tail."""
    result = F(0)
    opp = [j for j in range(4) if j != i]
    for bits in product((0,1), repeat=3):
        S = sum(bit << j for j,bit in zip(opp,bits))
        mass = F(1)
        for j,bit in zip(opp,bits):
            mass *= q[j] if bit else 1-q[j]
        if mass:
            assert S != 0, 'The tail is not screened.'
            result += mass * (R[S | (1 << i)][i] - R[S][i])
    return result

def is_root_nash(q):
    for i in range(4):
        gap = quit_minus_continue(i,q)
        if q[i] == 0 and gap > 0: return False
        if q[i] == 1 and gap < 0: return False
        if 0 < q[i] < 1 and gap != 0: return False
    return True

def verify_no_two_sure_root():
    """Enumerate all two-free-player supports, including degeneracy checks."""
    candidate_count = 0
    for sure in combinations(range(4),2):
        i,j = [k for k in range(4) if k not in sure]
        q = [F(int(k in sure)) for k in range(4)]
        # Pure/pure cases include every configuration with >=3 sure players.
        for qi,qj in product((F(0),F(1)), repeat=2):
            q[i],q[j] = qi,qj
            assert not is_root_nash(q), (sure, q)
            candidate_count += 1
        # A mixed/pure equilibrium would require one of these constant gaps=0.
        for mixer,other in ((i,j),(j,i)):
            for pure in (F(0),F(1)):
                q[mixer],q[other] = F(1,2),pure
                assert quit_minus_continue(mixer,q) != 0, 'Degenerate support.'
        # Mixed/mixed: each player's indifference determines the other's rate.
        q[i],q[j] = F(0),F(0)
        gi0,gj0 = quit_minus_continue(i,q),quit_minus_continue(j,q)
        q[j] = F(1)
        gi1 = quit_minus_continue(i,q)
        q[j],q[i] = F(0),F(1)
        gj1 = quit_minus_continue(j,q)
        if gi1 == gi0 or gj1 == gj0:
            assert gi0 != 0 and gj0 != 0
            continue
        q[i],q[j] = -gj0/(gj1-gj0),-gi0/(gi1-gi0)
        if all(0 < q[k] < 1 for k in (i,j)):
            assert not is_root_nash(q), (sure, q)
            candidate_count += 1
    return candidate_count

def main():
    assert tuple(R[1 << i][i] for i in range(4)) == SOLO
    for S in range(1,16):
        x,y = surplus_means(S)
        if S == 3: assert x <= 1 and y <= F(-3,4)
        elif S == 12: assert x <= F(-3,4) and y <= 1
        else: assert x <= -1 and y <= -1, (S,x,y)
    M = max(abs(value) for S,row in R.items() for value in row)
    assert M == F(17,4)
    joins = tuple(R[1 | (1 << j)][j] - R[1][j] for j in (1,2,3))
    assert joins == (F(3),F(17,4),F(1,4))
    observer = 2
    L = max(F(0), *(R[S][observer] for S in range(1,16)))
    kappa, g = F(3,8), joins[1]
    assert L == F(7,4)
    alpha = kappa*g/(4*M*(L+g+kappa))
    assert alpha == F(1,68)
    # A product root whose only active players are 0 and 1 violates product-low.
    assert R[3][0] > SOLO[0] and R[3][1] > SOLO[1]
    # A correlated lottery dominates all singletons; a linear positive-weight
    # social-payoff separation therefore cannot establish the payoff exclusion.
    lottery = tuple((R[3][i]+R[12][i])/2 for i in range(4))
    assert all(lottery[i]-SOLO[i] == F(1,8) for i in range(4))
    # Every nonempty pure terminal coalition has a strictly profitable toggle.
    pure_witnesses = {}
    for S in range(1,16):
        moves = [(i,S^(1<<i),R[S^(1<<i)][i]-R[S][i])
                 for i in range(4) if S^(1<<i) != 0
                 and R[S^(1<<i)][i] > R[S][i]]
        assert moves, ('Pure equilibrium',S)
        pure_witnesses[str(S)] = [moves[0][0],moves[0][1],str(moves[0][2])]
    tested = verify_no_two_sure_root()
    # A low-coordinate but non-realizable continuation admits an exact root
    # whose every active quitter is strictly above its singleton payoff.
    q = (F(1,100), F(1,10), F(0), F(0))
    v = (F(3,2), F(1,33), F(0), F(0))
    endpoint_report = []
    for i in range(4):
        opp = [j for j in range(4) if j != i]
        Q = C = F(0)
        for bits in product((0,1), repeat=3):
            S = sum(bit << j for j,bit in zip(opp,bits))
            mass = F(1)
            for j,bit in zip(opp,bits): mass *= q[j] if bit else 1-q[j]
            Q += mass * R[S | (1<<i)][i]
            C += mass * (R[S][i] if S else v[i])
        assert Q == C if q[i] > 0 else C >= Q
        if q[i] > 0: assert Q > SOLO[i]
        endpoint_report.append({'player':i, 'quit':str(Q), 'continue':str(C)})
    # Robust box: own singletons fixed, every other entry within 1/16.
    eta = F(1,16)
    alpha_robust = (kappa-eta)*(g-2*eta)/(4*(M+eta)*(L+eta+g-2*eta+kappa-eta))
    assert alpha_robust == F(11,920)
    report = {
        'exact_arithmetic': 'fractions.Fraction; no floating-point comparisons',
        'chamber_inequalities': 30,
        'singleton_vector': list(map(str,SOLO)),
        'reward_bound': str(M), 'payoff_deficit_kappa': str(kappa),
        'joining_gains': list(map(str,joins)),
        'observer': observer, 'observer_payoff_upper_bound': str(L),
        'opponent_absorption_floor': str(alpha),
        'full_regret_bound': '(67/68)^N',
        'robust_radius': str(eta), 'robust_absorption_floor': str(alpha_robust),
        'robust_full_regret_bound': '(909/920)^N',
        'two_sure_candidates_checked': tested,
        'two_sure_roots': 0,
        'unrealizable_continuation_bad_root_endpoints': endpoint_report,
        'pure_coalition_profitable_toggle_witnesses': pure_witnesses,
        'scope': 'Finite table checks only; no Lean check or universal Fin4 proof.'
    }
    folder = Path(__file__).resolve().parent
    (folder/'TABLE.json').write_text(json.dumps({str(S): list(map(str,row)) for S,row in R.items()},indent=2)+'\n')
    (folder/'CHECK_RESULTS.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__ == '__main__': main()
