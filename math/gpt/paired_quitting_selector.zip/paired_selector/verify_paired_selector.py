#!/usr/bin/env python3
"""Exact face-sign audit for the paired quitting-game selector.

Default: 512 exact Fraction evaluations; no third-party dependencies.
--numerical N: additionally test N independently perturbed, asymmetric tables
using SciPy. Numerical tests are regression evidence, not an existence proof.
The mathematical existence proof uses Poincare--Miranda plus these face signs.
"""
from __future__ import annotations
import argparse
from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path

LOW = F(1, 100)
HIGH = F(1, 2)
PARTNER = (2, 3, 0, 1)
PAIRS = ((0, 2), (1, 3))


def residual(h, u, v, s, b, p, a, c, d):
    """One player's active-pair indifference/Bellman residual."""
    x = s + h * (p - s)
    y = (x - h * b) / (1 - h)
    other_reward = u * (1-v) * a + (1-u) * v * c + u*v*d
    return y - (1-u) * (1-v) * x - other_reward


def exact_audit():
    # Order: own singleton, partner singleton, own pair, two opposite
    # singleton rewards, opposite pair reward.
    intervals = ((F(9,10), F(11,10)), (F(-1,10), F(1,10)),
                 (F(19,10), F(21,10)), (F(19,10), F(21,10)),
                 (F(19,10), F(21,10)), (F(-1,10), F(1,10)))
    rows = []
    for u, v in product((LOW, HIGH), repeat=2):
        lower = [residual(LOW, u, v, *reward)
                 for reward in product(*intervals)]
        upper = [residual(HIGH, u, v, *reward)
                 for reward in product(*intervals)]
        assert max(lower) < 0
        assert min(upper) > 0
        rows.append({"u": str(u), "v": str(v),
                     "lower_face_upper_bound": str(max(lower)),
                     "upper_face_lower_bound": str(min(upper))})
    # Inactive-player incentive margin, valid at every selected zero.
    margin = LOW / (1-LOW) * F(9,5) - F(1,50) * F(3,4)
    assert margin == F(7,2200) and margin > 0
    return {"exact_fraction_evaluations": 512,
            "face_bounds": rows, "inactive_margin_lower_bound": str(margin)}


def exact_reference_selector():
    """An explicit canonical (1,0,0,0) finite selector at the class center.

    The bound is justified by Section 4 of PAIRED_QUITTING_SELECTOR.md.
    Every inequality deciding acceptance is evaluated in Fraction arithmetic.
    """
    q = F(139194147, 10**9)
    K = 30
    h = residual(q, q, q, F(1), F(0), F(2), F(2), F(2), F(0))
    x, y = 1+q, 1+2*q/(1-q)
    C, D = (1-q)**4, (1-q)**3
    normalized_vmax = max(x, y-1)
    bound = C**K*normalized_vmax + abs(h)/(1-C) + abs(h)/(1-D)
    accuracy = F(1, 10**6)
    assert LOW < q < HIGH
    assert bound < accuracy
    return {
        "hazard": str(q), "complete_periods": K, "finite_dates": 2*K,
        "own_singletons": [1, 0, 0, 0],
        "exact_residual": str(h), "requested_accuracy": str(accuracy),
        "regret_bound_display_only": float(bound),
        "certified_by_fraction_comparison": True,
        "description": "The exact residual bound is strictly below 1/1000000. "
                       "The decimal is only a display of that rational bound."
    }


def numerical_audit(count: int, seed: int):
    import numpy as np
    from scipy.optimize import least_squares
    rng = np.random.default_rng(seed)

    def row_data(reward, q):
        prescribed = np.zeros(4)
        survival = float(np.prod(1-q))
        for mask in range(1, 16):
            prob = np.prod([q[j] if mask >> j & 1 else 1-q[j]
                            for j in range(4)])
            prescribed += prob * reward[mask]
        quit_payoff, passive, deleted_survival = (np.zeros(4) for _ in range(3))
        for i in range(4):
            for mask in range(16):
                if mask >> i & 1:
                    continue
                prob = np.prod([q[j] if mask >> j & 1 else 1-q[j]
                                for j in range(4) if j != i])
                quit_payoff[i] += prob * reward[mask | (1 << i), i]
                if mask:
                    passive[i] += prob * reward[mask, i]
                else:
                    deleted_survival[i] = prob
        return prescribed, survival, quit_payoff, passive, deleted_survival

    def finite_semantics(reward, rows):
        # After the displayed menu opponents never quit. A responder may still
        # choose any late finite time, as well as Never. Include that cap here.
        value = np.zeros(4)
        cap = np.maximum(0, np.array([reward[1 << i, i] for i in range(4)]))
        for row in reversed(rows):
            immediate, survive, quit_now, passive, deleted = row_data(reward, row)
            value = immediate + survive * value
            cap = np.maximum(quit_now, passive + deleted * cap)
        return value, cap

    largest = {"root_residual": 0.0, "periodic_regret": 0.0,
               "truncation_identity_error": 0.0, "repaired_pivot_regret": 0.0}
    for test in range(count):
        # Payoffs not used by the proof are genuinely unconstrained.
        reward = rng.uniform(-20, 20, (16, 4))
        reward[0] = 0
        for i in range(4):
            j = PARTNER[i]
            k, l = [z for z in range(4) if z not in (i, j)]
            s = rng.uniform(.9, 1.1)
            reward[1 << i, i] = s
            reward[1 << j, i] = rng.uniform(-.1, .1)
            reward[(1 << i) | (1 << j), i] = rng.uniform(1.9, 2.1)
            reward[1 << k, i] = rng.uniform(1.9, 2.1)
            reward[1 << l, i] = rng.uniform(1.9, 2.1)
            reward[(1 << k) | (1 << l), i] = rng.uniform(-.1, .1)
            for T in ((1 << k), (1 << l), (1 << k) | (1 << l)):
                reward[(1 << i) | T, i] = rng.uniform(s-3, s+.02)

        def field(q):
            out = np.empty(4)
            for i in range(4):
                j = PARTNER[i]
                k, l = [z for z in range(4) if z not in (i, j)]
                out[j] = residual(q[j], q[k], q[l], reward[1 << i, i],
                    reward[1 << j, i], reward[(1 << i) | (1 << j), i],
                    reward[1 << k, i], reward[1 << l, i],
                    reward[(1 << k) | (1 << l), i])
            return out

        fit = least_squares(field, np.full(4, .14), bounds=(.01, .5),
                            xtol=1e-13, ftol=1e-13, gtol=1e-13,
                            max_nfev=3000)
        q = fit.x
        root_error = float(np.max(np.abs(field(q))))
        assert root_error < 1e-9, (test, fit.message, root_error)
        qa, qb = np.zeros(4), np.zeros(4)
        qa[list(PAIRS[0])] = q[list(PAIRS[0])]
        qb[list(PAIRS[1])] = q[list(PAIRS[1])]
        Ra, ca, Qa, Oa, da = row_data(reward, qa)
        Rb, cb, Qb, Ob, db = row_data(reward, qb)
        value = (Ra + ca*Rb) / (1-ca*cb)
        # Complete stopping envelope: Quit in the first A phase, Quit in the
        # first B phase, or Never. Later pure dates interpolate with Never.
        never = (Oa + da*Ob) / (1-da*db)
        cap = np.maximum.reduce((Qa, Oa+da*Qb, never))
        regret = float(np.max(np.abs(cap-value)))
        assert regret < 1e-8, (test, cap, value)
        C = ca*cb
        largest["root_residual"] = max(largest["root_residual"], root_error)
        largest["periodic_regret"] = max(largest["periodic_regret"], regret)
        for K in (1, 2, 5, 12):
            rows = [x.copy() for _ in range(K) for x in (qa, qb)]
            finite_value, finite_cap = finite_semantics(reward, rows)
            identity_error = max(float(np.max(np.abs(finite_cap-value))),
                float(np.max(np.abs(finite_value-(1-C**K)*value))))
            assert identity_error < 1e-8, (test, K, identity_error)
            largest["truncation_identity_error"] = max(
                largest["truncation_identity_error"], identity_error)
            # Put the pivot's original Never atom on its last active date.
            # All earlier pivot hazards remain q[0]; the last one becomes 1.
            rows[2*K-2][0] = 1
            repaired_value, repaired_cap = finite_semantics(reward, rows)
            pivot_regret = float(abs(repaired_cap[0]-repaired_value[0]))
            assert pivot_regret < 1e-8
            largest["repaired_pivot_regret"] = max(
                largest["repaired_pivot_regret"], pivot_regret)
            M = float(np.max(np.abs(reward)))
            bound = C**K * float(np.max(value)) + 4*M*.99**(3*K-2)
            assert np.max(repaired_cap-repaired_value) <= bound+1e-8
    return {"tables": count, "seed": seed, "largest_errors": largest,
            "warning": "Floating-point regression tests, not formal proofs."}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--numerical', type=int, default=0, metavar='N')
    parser.add_argument('--seed', type=int, default=20260906)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    if args.numerical < 0:
        parser.error('--numerical must be nonnegative')
    result = {"exact_audit": exact_audit(),
              "exact_reference_selector": exact_reference_selector()}
    if args.numerical:
        result["numerical_audit"] = numerical_audit(args.numerical, args.seed)
    text = json.dumps(result, indent=2)
    print(text)
    if args.output:
        args.output.write_text(text+'\n', encoding='utf-8')


if __name__ == '__main__':
    main()
