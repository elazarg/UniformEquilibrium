from fractions import Fraction as F
from itertools import product
from random import Random
from check_compression import quantile, clock_compress, semantic, cdf_distance

rng = Random(22841)
n, m, K = 3, 3, 7
r = {frozenset(i for i, x in enumerate(bits) if x):
     tuple(F(rng.randrange(-7,8),7) for _ in range(n))
     for bits in product((0,1), repeat=n) if any(bits)}
family = [
    [{None:F(1)}, {0:F(1,3),999:F(2,3)}, {2:F(3,4),None:F(1,4)}],
    [{1:F(1,2),999:F(1,2)}, {None:F(1)}, {1000:F(1)}],
    [{0:F(1,4),200000:F(3,4)}, {1:F(1,2),None:F(1,2)}, {None:F(1)}],
]
q_family = [[quantile(law,K) for law in p] for p in family]
c_family = clock_compress(q_family)

def mixture(sources, i, weights):
    out = {}
    for a, w in enumerate(weights):
        for t, mass in sources[a][i].items():
            out[t] = out.get(t,F(0)) + w*mass
    return {t: mass for t,mass in out.items() if mass}

for _ in range(100):
    weights=[]
    for i in range(n):
        raw=[rng.randrange(1,8) for _ in range(m)]
        weights.append([F(a,sum(raw)) for a in raw])
    p=[mixture(family,i,weights[i]) for i in range(n)]
    q=[mixture(q_family,i,weights[i]) for i in range(n)]
    c=[mixture(c_family,i,weights[i]) for i in range(n)]
    assert all(cdf_distance(p[i],q[i]) <= F(1,2*K) for i in range(n))
    sp,sq,sc=semantic(r,p),semantic(r,q),semantic(r,c)
    assert sq == sc
    assert abs(sp[3]-sc[3]) <= F(4*n-2,K)
print('PASS: 100 exact-rational cross-face mixtures, with independent coordinate weights.')
