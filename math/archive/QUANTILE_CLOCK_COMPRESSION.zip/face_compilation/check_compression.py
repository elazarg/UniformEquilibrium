"""Exact arithmetic checks for quitting-game quantile and clock compression.

Stopping times are nonnegative integers; None means Never.
This script is a regression check, not a proof of equilibrium existence.
"""
from __future__ import annotations
from fractions import Fraction as F
from itertools import product
from typing import Optional
import random

Time = Optional[int]
Law = dict[Time, F]
Profile = list[Law]
Reward = dict[frozenset[int], tuple[F, ...]]


def check_law(law: Law) -> None:
    assert all(t is None or isinstance(t, int) and t >= 0 for t in law)
    assert all(a >= 0 for a in law.values())
    assert sum(law.values(), F(0)) == 1


def payoff(r: Reward, p: Profile) -> tuple[F, ...]:
    n = len(p)
    out = [F(0)] * n
    for atoms in product(*(list(x.items()) for x in p)):
        mass = F(1)
        for _, a in atoms:
            mass *= a
        finite = [t for t, _ in atoms if t is not None]
        if not finite or not mass:
            continue
        first = min(finite)
        coalition = frozenset(i for i, (t, _) in enumerate(atoms) if t == first)
        for i in range(n):
            out[i] += mass * r[coalition][i]
    return tuple(out)


def reply_times(p: Profile, who: int) -> list[Time]:
    """Represent every pure reply, including empty gaps and late dates."""
    support = sorted({t for j, law in enumerate(p) if j != who
                      for t, a in law.items() if t is not None and a})
    tests: set[int] = {0}
    for t in support:
        tests.add(t)
        tests.add(t + 1)
    return sorted(tests) + [None]


def semantic(r: Reward, p: Profile):
    u = payoff(r, p)
    caps = []
    for i in range(len(p)):
        values = []
        for t in reply_times(p, i):
            updated = list(p)
            updated[i] = {t: F(1)}
            values.append(payoff(r, updated)[i])
        caps.append(max(values))
    debts = tuple(caps[i] - u[i] for i in range(len(p)))
    assert min(debts) >= 0
    return u, tuple(caps), debts, max(debts)


def quantile(law: Law, k: int) -> Law:
    """Midpoint empirical quantiles: finite-CDF error at most 1/(2k)."""
    check_law(law)
    if k < 1:
        raise ValueError("k must be positive")
    cumulative = []
    total = F(0)
    for t in sorted(t for t in law if t is not None):
        total += law[t]
        cumulative.append((t, total))
    out: Law = {}
    for j in range(1, k + 1):
        level = F(2*j-1, 2*k)
        t = next((t for t, value in cumulative if level <= value), None)
        out[t] = out.get(t, F(0)) + F(1, k)
    check_law(out)
    return out


def cdf_distance(p: Law, q: Law) -> F:
    times = sorted({t for x in (p, q) for t in x if t is not None})
    return max([F(0)] + [abs(sum((a for s, a in p.items() if s is not None and s <= t), F(0))
                              - sum((a for s, a in q.items() if s is not None and s <= t), F(0)))
                         for t in times])


def clock_compress(family: list[Profile]) -> list[Profile]:
    """Use one clock for a family; preserve ties and empty-deviation slots."""
    times = sorted({t for p in family for law in p for t, a in law.items()
                    if t is not None and a})
    image: dict[Time, Time] = {None: None}
    if times:
        image[times[0]] = min(times[0], 1)
        for old, new in zip(times, times[1:]):
            image[new] = image[old] + min(new-old, 2)
    return [[{image[t]: a for t, a in law.items() if a}
             for law in p] for p in family]


def randomized_checks(trials: int = 120, seed: int = 871236) -> None:
    rng = random.Random(seed)
    for trial in range(trials):
        n = rng.choice([2, 3, 4])
        r: Reward = {}
        for bits in product([False, True], repeat=n):
            s = frozenset(i for i, bit in enumerate(bits) if bit)
            if s:
                r[s] = tuple(F(rng.randrange(-10, 11), 10) for _ in range(n))
        p = []
        for i in range(n):
            dates = sorted(rng.sample(range(0, 10000), 3))
            if rng.randrange(2):
                dates[0] = 0
            if rng.randrange(2):
                dates[1] = dates[0] + 1
            numerators = [rng.randrange(0, 10) for _ in range(4)]
            if not sum(numerators):
                numerators[-1] = 1
            denom = sum(numerators)
            p.append({t: F(a, denom) for t, a in zip(dates+[None], numerators) if a})
        k = rng.randrange(1, 16)
        q = [quantile(law, k) for law in p]
        errors = [cdf_distance(a, b) for a, b in zip(p, q)]
        assert max(errors) <= F(1, 2*k)
        sp, sq = semantic(r, p), semantic(r, q)
        for i in range(n):
            assert abs(sp[0][i]-sq[0][i]) <= 4*sum(errors)
            assert abs(sp[1][i]-sq[1][i]) <= 4*sum(errors[j] for j in range(n) if j != i)
            assert abs(sp[2][i]-sq[2][i]) <= F(4*n-2, k)
        assert abs(sp[3]-sq[3]) <= F(4*n-2, k)
        compressed = clock_compress([q])[0]
        assert semantic(r, compressed) == sq
        assert all(t is None or t < 2*n*k for law in compressed for t in law)
    print(f"PASS: {trials} exact-rational randomized checks (2--4 players).")


def shared_clock_regression() -> None:
    # Adjacent prescribed dates must remain adjacent; otherwise a new reply
    # can appear. Long gaps need just one empty date.
    p = [{0:F(1,2), 1:F(1,2)}, {1:F(1,3), 100:F(1,3), None:F(1,3)}]
    q = [{10:F(1)}, {10000:F(1)}]
    cp, cq = clock_compress([p,q])
    assert set(cp[0]) == {0,1}
    assert set(cp[1]) == {1,5,None}
    assert set(cq[0]) == {3}
    assert set(cq[1]) == {7}
    print("PASS: common-clock adjacency / long-gap regression.")

if __name__ == '__main__':
    shared_clock_regression()
    randomized_checks()
